# bums_consumer_ui.py
import threading

import pika
import json
import tkinter as tk
from tkinter import messagebox

class BUMSUI:
    def __init__(self, root):
        self.root = root
        self.root.title("BUMS - Budget Utilization & Monitoring")
        self.root.geometry("620x540")
        self.root.configure(bg="#1e1e2f")  # Dark futuristic background

        # Header
        self.header_frame = tk.Frame(root, bg="#800000", height=60)
        self.header_frame.pack(fill=tk.X)
        self.title_label = tk.Label(self.header_frame, text="💼 BUMS - Budget Utilization & Monitoring",
                                    font=("Segoe UI", 18, "bold"), fg="white", bg="#800000")
        self.title_label.pack(pady=10)

        # Status Label
        self.status_label = tk.Label(root, text="🔄 Waiting for budget data from EBPPro...",
                                     font=("Segoe UI", 13), bg="#1e1e2f", fg="#bbbbbb")
        self.status_label.pack(pady=(20, 10))

        # Received Data Display
        self.data_label = tk.Label(root, text="No Data Received Yet", font=("Segoe UI", 12),
                                   bg="#1e1e2f", fg="white", wraplength=500, justify="left")
        self.data_label.pack(pady=5)

        # Sync Button (with hover effect)
        self.sync_button = tk.Button(root, text="⚡ Sync with EBPPro", font=("Segoe UI", 12, "bold"),
                                     bg="#800000", fg="white", activebackground="#800000",
                                     padx=15, pady=7, bd=0, relief=tk.FLAT,
                                     command=self.sync_with_ebppro)
        self.sync_button.pack(pady=20)
        self.sync_button.configure(cursor="hand2")

        # Hover effect for button
        self.sync_button.bind("<Enter>", lambda e: self.sync_button.config(bg="#a52a2a"))
        self.sync_button.bind("<Leave>", lambda e: self.sync_button.config(bg="#800000"))

        # Audit Trail Label
        self.audit_label = tk.Label(root, text="📋 Audit Trail", font=("Segoe UI", 13, "bold"),
                                    bg="#1e1e2f", fg="#bbbbbb")
        self.audit_label.pack(pady=(20, 5))

        # Audit Trail Box
        self.audit_box = tk.Text(root, height=10, width=65, wrap=tk.WORD, state=tk.DISABLED,
                                 font=("Consolas", 10), bg="#2a2a3d", fg="white", relief=tk.FLAT)
        self.audit_box.pack(pady=5)

    def sync_with_ebppro(self):
        def consume():
            try:
                connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
                channel = connection.channel()
                channel.queue_declare(queue='ebp_to_bums_queue', durable=True)

                def callback(ch, method, properties, body):
                    data = json.loads(body)
                    print("Received message:", data)
                    self.root.after(0, lambda: self.status_label.config(text="✅ Data successfully synced from EBPPro"))
                    self.root.after(0, lambda: self.data_label.config(
                        text=f"📦 Received Data:\n{json.dumps(data, indent=2)}"))
                    self.root.after(0, lambda: self.update_audit_log("Received: " + str(data)))

                    # Optional: Stop consuming after first message (to prevent crash)
                    ch.stop_consuming()

                print("Waiting for messages from EBPPro...")
                channel.basic_consume(queue='ebp_to_bums_queue', on_message_callback=callback, auto_ack=True)
                channel.start_consuming()
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", f"An error occurred: {e}"))

        # Start the consumer in a new thread
        threading.Thread(target=consume, daemon=True).start()

    def update_audit_log(self, message):
        self.audit_box.config(state=tk.NORMAL)
        self.audit_box.insert(tk.END, message + '\n')
        self.audit_box.config(state=tk.DISABLED)

# Run the UI
if __name__ == "__main__":
    root = tk.Tk()
    app = BUMSUI(root)
    root.mainloop()