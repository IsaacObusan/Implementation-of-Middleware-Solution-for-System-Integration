# rest_api_server.py
from flask import Flask, request, jsonify
import pika
import json

app = Flask(__name__)

@app.route('/api/budget', methods=['POST'])
def send_budget():
    data = request.json
    try:
        connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
        channel = connection.channel()

        channel.exchange_declare(exchange='data_exchange', exchange_type='direct')
        channel.queue_declare(queue='ebp_to_bums_queue', durable=True)
        channel.queue_bind(exchange='data_exchange', queue='ebp_to_bums_queue', routing_key='to_bums')

        channel.basic_publish(
            exchange='data_exchange',
            routing_key='to_bums',
            body=json.dumps(data),
            properties=pika.BasicProperties(delivery_mode=2)
        )

        connection.close()
        return jsonify({'status': 'success', 'message': 'Budget data sent to BUMS'}), 200
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'running'}), 200


if __name__ == '__main__':
    # Make sure the server listens to localhost
    app.run(host='127.0.0.1', port=5000)
