# ebppro_producer_ui.py
import pika
import json
import tkinter as tk
from tkinter import messagebox

class EBPProUI:
    def __init__(self, root):
        self.root = root
        self.root.title("EBPPro - Electronic Budget Planning")
        self.root.geometry("500x500")
        self.root.configure(bg="#1e1e2f")  # Futuristic dark background

        # Header
        self.header = tk.Label(root, text="EBPPro - Electronic Budget Planning", bg="#800000", fg="white",
                               font=("Helvetica", 16, "bold"), pady=10)
        self.header.pack(fill=tk.X)

        # Status Label
        self.status_label = tk.Label(root, text="Status: Waiting for budget data...",
                                     font=("Helvetica", 12), fg="white", bg="#1e1e2f")
        self.status_label.pack(pady=20)

        # Send Button (custom hover effect)
        self.send_button = tk.Button(root, text="Send to BUMS Now",
                                     command=self.send_to_bums,
                                     font=("Helvetica", 12, "bold"),
                                     bg="#800000", fg="white", activebackground="#a52a2a", bd=0,
                                     relief=tk.FLAT, padx=10, pady=5)
        self.send_button.pack(pady=10)

        self.send_button.bind("<Enter>", self.on_enter)
        self.send_button.bind("<Leave>", self.on_leave)

        # Log area
        self.log_label = tk.Label(root, text="History Log", font=("Helvetica", 12, "bold"),
                                  fg="white", bg="#1c1c1c")
        self.log_label.pack(pady=10)

        self.log_box = tk.Text(root, height=10, width=55, wrap=tk.WORD, bg="#333", fg="white",
                               font=("Courier", 10), state=tk.DISABLED, bd=2, relief=tk.FLAT)
        self.log_box.pack(pady=10)

        # Example Payload
        self.tob_data = {
            "operation": "upload_tob",
            "department": "Finance",
            "budget": 125000,
            "timestamp": "2025-05-14T09:00:00"
        }

    def on_enter(self, event):
        event.widget.config(bg="#a52a2a")

    def on_leave(self, event):
        event.widget.config(bg="#800000")

    def send_to_bums(self):
        try:
            # Connect to RabbitMQ
            connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
            channel = connection.channel()

            channel.exchange_declare(exchange='data_exchange', exchange_type='direct')
            channel.queue_declare(queue='ebp_to_bums_queue', durable=True)
            channel.queue_bind(exchange='data_exchange', queue='ebp_to_bums_queue', routing_key='to_bums')

            channel.basic_publish(
                exchange='data_exchange',
                routing_key='to_bums',
                body=json.dumps(self.tob_data),
                properties=pika.BasicProperties(delivery_mode=2)
            )
            connection.close()

            self.status_label.config(text="✅ Budget data successfully transferred!")
            self.update_log("Sent to BUMS: " + str(self.tob_data))
        except Exception as e:
            self.status_label.config(text="❌ Failed to transfer data")
            messagebox.showerror("Error", f"An error occurred: {e}")

    def update_log(self, message):
        self.log_box.config(state=tk.NORMAL)
        self.log_box.insert(tk.END, message + '\n')
        self.log_box.config(state=tk.DISABLED)


# Main UI window
root = tk.Tk()
app = EBPProUI(root)
root.mainloop()